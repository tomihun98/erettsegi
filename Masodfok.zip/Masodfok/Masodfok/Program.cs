﻿// See https://aka.ms/new-console-template for more information

double a;
double b;
double c;
double d;
double x1;
double x2;


Console.WriteLine("Ez a program a másodfokú programot számolja ki!");
Console.WriteLine("Add meg az a értéket?");
a = Convert.ToDouble(Console.ReadLine());
if (a == 0)
{
    Console.WriteLine("/Ez az egyenlet így nem lehet másodfokú");

}

else
{
    Console.WriteLine("Add meg a b értékét");

}