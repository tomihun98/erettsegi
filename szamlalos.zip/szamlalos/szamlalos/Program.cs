﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Ez a program összeadd ,kivon ,szoroz, oszt");
Console.WriteLine("Addjon meg egy számot !");
Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Adjon meg mégegy számot !");
Convert.ToDouble(Console.ReadLine());

int szám = Convert.ToInt32(Console.ReadLine());
int szám2 = Convert.ToInt32(Console.ReadLine());


switch (szám)
{
    case 1:
        Console.WriteLine(szám+szám2);
        break;
    case 2:
        Console.WriteLine(szám-szám2);
        break;
    case 3:
        Console.WriteLine(szám*szám2);
        break;
    case 4:
        Console.WriteLine(szám/szám2);
        break;

    default:
        break;
}



