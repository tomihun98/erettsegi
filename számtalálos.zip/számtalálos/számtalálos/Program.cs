﻿Console.WriteLine("Ez egy számkitalálos gép, kérem gondolj rá egy számra 1 és 100 között! ÉS ÉN KIFOGM TALALNI A SZÁMOT");
int random_number = new Random().Next(1, 101);
Random kor = new Random();
int szam = random_number;
Console.WriteLine("Kérem adjon meg egy számot");
    do
{
    Console.WriteLine(random_number  kor);
}
    